import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer

# Load the dataset
df = pd.read_csv('IOT_Datasets.csv')
print(df.head())

# Define features and target
X = df.drop(['Label'], axis=1)
y = df['Label']

# Preprocessing
numeric_features = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI',
                    'DiabetesPedigreeFunction', 'Age', 'chol', 'oldpeak']
categorical_features = ['Gender', 'smoking', 'thal']

# Pipelines for preprocessing
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(transformers=[
    ('num', numeric_transformer, numeric_features),
    ('cat', categorical_transformer, categorical_features)
])

# Models
models = {
    'Logistic Regression': LogisticRegression(),
    'Random Forest': RandomForestClassifier(),
    'XGBoost': XGBClassifier(eval_metric='logloss'),
    'SVM': LinearSVC(max_iter=10000)
}

# Train and evaluate
for model_name, model in models.items():
    pipeline = Pipeline(steps=[('preprocessor', preprocessor),
                               ('classifier', model)])
    
    # Fit the model
    pipeline.fit(X, y)

    # Cross-validation
    scores = cross_val_score(pipeline, X, y, cv=5, scoring='accuracy')
    print(f'{model_name} Cross-Validated Accuracy: {scores.mean():.4f}')

    # Final evaluation on same data (note: for real use, split train/test)
    y_pred = pipeline.predict(X)
    print(f'{model_name} Accuracy Score: {accuracy_score(y, y_pred):.4f}\n')
